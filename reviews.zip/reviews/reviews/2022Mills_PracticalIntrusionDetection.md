

- General Info
   - paper title: Practical Intrusion Detection of Emerging Threats
   - conference/journal: TNSM
   - year: 2022
   - dataset
     - [x] own dataset
     - [ ] Botnet
     - [ ] AWID
     - [ ] CIC DoS
     - [ ] CIDDS-001 
     - [ ] KDD CUP 99
     - [ ] CICIDS 2017 
     - [ ] CIDDS-002 
     - [ ] Kyoto 2006+
     - [ ] DARPA 
     - [ ] ISCX 2012
     - [ ] NSL-KDD
     - [ ] DDoS 2016 
     - [ ] TUIDS
     - [ ] ISCX 2012
     - [ ] Twente
     - [ ] ISOT
     - [ ] NDSec-1
     - [ ] NGIDS-DS
     - [ ] TRAbID
     - [ ] TUIDS
     - [ ] UNSW-NB15
     - [ ] PU-IDS
     - [ ] SSENET-2011
     - [ ] IRSC
     - [ ] SANTA
     - [ ] CTU-13
     - [ ] UGR’16
     - [ ] PUF
     - [ ] SSHCure
     - [ ] Booters
     - [ ] Kent 2016
     - [ ] CDX
     - [ ] UNIBS
     - [ ] LBNL
     - [ ] Unified Host and Network
     - [x] OTHER: contains a summary of IDS datasets (e.g., simulated or not)
   - utilized model 
     - [x] supervised
       - [x] Decision Tree
       - [x] Logistic Regression
       - [x] Naive Bayes
       - [x] Random Forest
       - [ ] K-Nearest Neighbours
       - [x] Support Vector Machine
       - [ ] Neural Networks
       - [x] OTHER: Gradient Boosted Tree
     - [x] unsupervised
       - [x] k-Means
       - [ ] fuzzy-c-means
       - [ ] DBSCAN
       - [ ] HDBSCAN
       - [ ] Neural Networks
       - [x] OTHER: they also use clustering to label their data, but I think this is a different use 
     - [ ] OTHER:



- [ ] H1 Data too old (with respect to the newest utilized dataset)
    - [ ] older than Wikipedia (2001)
    - [ ] older than Facebook (2004)
    - [ ] older than youtube (2005)
    - [ ] older than Netflix and iPhone (2007)
    - [ ] older than Instagram (2010)
    - [ ] older than QUIC Protocol (2016)  
    - [ ] no info on data recording date
    - [ ] OTHER:


- [ ] H2 Data/traffic mix not justified or explained
    - [ ] no (attempt of) explanation of usage of this particular traffic mixture
    - [ ] OTHER:


- [ ] H3 Data not available for own experiments
    - [ ] not publicly downloadable
    - [ ] OTHER:


- [ ] H4 Code or pseudocode (in the strict sense/PASCAL-like) not available for own experiments
    - [ ] no mention of github, sourceforge, or dockerhub
    - [ ] no appearance of string pseudocode
    - [x] OTHER: https://github.com/ruzzzzz/Citrus



- [x] H5 Potential model overfitting/model potentially not generalizable to own scenario
    - [x] used only one dataset
    - [ ] based on simulated/laboratory data, which is optimised for a single environment (5)
    - [ ] not dealing with enterprise-network changes (5)
    - [ ] ignoring diversity of network traffic (5)
    - [ ] OTHER:



- [x] H6 unusable in practise,  as required data is problematic to obtain
   - [ ] DNS activity (5)
   - [x] MORE THAN Netflow, proxy and firewall logs (5)
   - [x] OTHER: Cisco Joy - libpcap


- [x] H7 Unrealistic/high effort for data collection/monitoring
    - [ ] not sampled/aggregated
    - [ ] long duration (with respect to collection of training data)
    - [x] full resolution (pcaps)
    - [x] OTHER: it is not clear if they actually use pcaps


- [x] H8 Special/excessive processing hardware requirements
   - [x] cluster
   - [ ] GPU/Cuda...
   - [ ] unspecified hardware requirements
   - [ ] OTHER:



- [ ] H11 Model complexity too high for persona, not understandable/explainable, missing trust/explainability
    - [ ] black box model
    - [ ] various sequential or parallel models
    - [ ] cutting edge models
    - [ ] unclear/missing parameter setting
    - [x] OTHER: different models used


- [x] H12 Features not motivated/too complex for persona, missing trust/explainability
    - [ ] no explicit explanation given (domain interpretation)
    - [x] trust not considered/features are comprehensible
    - [x] excessive number of features (more than 7 +-2 according to The Magical Number Seven of George Miller) 
    - [ ] unknown/incomplete list of features
    - [ ] complicated pre-processing (transformations, data wrangling etc.)
    - [x] OTHER: features inspired by other datasets in IDS context


- [x] H13 Unclear meaning of decision/result
   - [x] no sound explanation of decision, e.g. with plot of decision tree, feature importances, explained thresholds/scores
   - [ ] no explanation of results giving context in domainuse case terms (e.g. for finding the root cause)
   - [x] no confidence/severity of results given to the users
   - [ ] meaning of results to users not discussed
   - [x] OTHER: explanation? "Due to this, we conclude Citrus can be leveraged to detect emerging threats in large-scale networked environments."

- [x] H15 Important usability/interaction features (for some personas) are missing
    - [x] no UI/User Interface/Visualization
    - [x] no sophisticated graphical representation ('glyphs', 'highlighting') - more than standard plots (ROC,...)
    - [x] no user interaction defined (refine, scale, select, ignore, sort)
    - [x] OTHER: plots are the UI???


- [x] H16 Privacy not in researchers' focus
    - [ ] invasive/payload-related methods for data collection (DPI, SSL-interception, code on user devices)
    - [x] privacy, pseudonymization, anonymization, differential privacy not mentioned
    - [x] OTHER: they anonymised the IP addresses but privacy is not the main part of the work


- [x] H17 false positive rate non-acceptable in practise considering expected number of events (in relation to worst case)
  - [ ] FPR too high (>1%)
  - [x] FPR not given
  - [x] FPs not given
  - [x] no confidence/severity additionally given
  - [x] no implications/interpretation of high/low FN/FP/TN/TP...
  - [x] OTHER: i guess FPR is < 10%, but no exact values give ("recall is over 90%")


- [ ] H18 no comparison with state-of-the-art given    
    - [ ] no comparison to other ML-based approaches
    - [ ] no mention of early detection, multistage attack
    - [ ] no comparision with suricata, snort,... (no comparison with signature based ids given)
    - [x] OTHER: comparison with B-IDS?


- [x] H19 ignored domain knowledge
    - [ ] approach neglects contextual information  (Goodall The Work of Intrusion Detection...)
    - [ ] intelligence not gathered from open source/commercial sources (5) (e.g., federated learning) - httpstalosintelligence.com
    - [x] Expert analysts cannot suggest improvements to a model by providing their feedback (7) (e.g., active learning)
    - [x] OTHER: not sure about the other two (approach vs. ML only)

- [x] H20 no discussion of limitations/evasions
    - [ ] OTHER:
