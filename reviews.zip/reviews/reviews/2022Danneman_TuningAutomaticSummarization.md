

- General Info
   - paper title: Tuning Automatic Summarization for Incident Report Visualization
   - conference/journal: PacificVis
   - year: 2022
   - dataset
     - [x] own dataset
     - [ ] Botnet
     - [ ] AWID
     - [ ] CIC DoS
     - [ ] CIDDS-001 
     - [ ] KDD CUP 99
     - [ ] CICIDS 2017 
     - [ ] CIDDS-002 
     - [ ] Kyoto 2006+
     - [ ] DARPA 
     - [ ] NSL-KDD
     - [ ] DDoS 2016 
     - [ ] TUIDS
     - [ ] ISCX 2012
     - [ ] Twente
     - [ ] ISOT
     - [ ] NDSec-1
     - [ ] NGIDS-DS
     - [ ] TRAbID
     - [ ] TUIDS
     - [ ] UNSW-NB15
     - [ ] PU-IDS
     - [ ] SSENET-2011
     - [ ] IRSC
     - [ ] SANTA
     - [ ] CTU-13
     - [ ] UGR’16
     - [ ] PUF
     - [ ] SSHCure
     - [ ] Booters
     - [ ] Kent 2016
     - [ ] CDX
     - [ ] UNIBS
     - [ ] LBNL
     - [ ] Unified Host and Network
     - [ ] OTHER: incident report data
   - utilized model 
     - [x] supervised
       - [ ] Decision Tree
       - [ ] Logistic Regression
       - [ ] Naive Bayes
       - [ ] Random Forest
       - [ ] K-Nearest Neighbours
       - [ ] Support Vector Machine
       - [x] Neural Networks
       - [ ] OTHER:
     - [ ] unsupervised
       - [ ] k-Means
       - [ ] fuzzy-c-means
       - [ ] DBSCAN
       - [ ] HDBSCAN
       - [ ] Neural Networks
       - [ ] OTHER:
     - [x] OTHER: statistical models such as Bayesian hierarchical model



- [x] H1 Data too old (with respect to the newest utilized dataset)
    - [ ] older than Wikipedia (2001)
    - [ ] older than Facebook (2004)
    - [ ] older than youtube (2005)
    - [ ] older than Netflix and iPhone (2007)
    - [ ] older than Instagram (2010)
    - [ ] older than QUIC Protocol (2016)  
    - [x] no info on data recording date
    - [ ] OTHER:


- [ ] H2 Data/traffic mix not justified or explained
    - [ ] no (attempt of) explanation of usage of this particular traffic mixture
    - [ ] OTHER: self-explanatory imo


- [x] H3 Data not available for own experiments
    - [x] not publicly downloadable
    - [ ] OTHER:


- [x] H4 Code or pseudocode (in the strict sense/PASCAL-like) not available for own experiments
    - [x] no mention of github, sourceforge, or dockerhub
    - [x] no appearance of string pseudocode
    - [ ] OTHER: theres a link to BZAR but thats just a tool they used



- [x] H5 Potential model overfitting/model potentially not generalizable to own scenario
    - [x] used only one dataset
    - [ ] based on simulated/laboratory data, which is optimised for a single environment (5)
    - [ ] not dealing with enterprise-network changes (5)
    - [ ] ignoring diversity of network traffic (5)
    - [x] OTHER: imo since its realistic data the last two points are addressed per default



- [x] H6 unusable in practise,  as required data is problematic to obtain
   - [ ] DNS activity (5)
   - [x] MORE THAN Netflow, proxy and firewall logs (5)
   - [x] OTHER: unsure, since no description, but they have definitely more than netflow


- [x] H7 Unrealistic/high effort for data collection/monitoring
    - [ ] not sampled/aggregated
    - [ ] long duration (with respect to collection of training data)
    - [ ] full resolution (pcaps)
    - [x] OTHER: unknown


- [x] H8 Special/excessive processing hardware requirements
   - [ ] cluster
   - [ ] GPU/Cuda...
   - [x] unspecified hardware requirements
   - [ ] OTHER:



- [x] H11 Model complexity too high for persona, not understandable/explainable, missing trust/explainability
    - [x] black box model
    - [ ] various sequential or parallel models
    - [ ] cutting edge models
    - [x] unclear/missing parameter setting
    - [ ] OTHER:


- [x] H12 Features not motivated/too complex for persona, missing trust/explainability
    - [ ] no explicit explanation given (domain interpretation)
    - [ ] trust not considered/features are comprehensible
    - [x] excessive number of features (more than 7 +-2 according to The Magical Number Seven of George Miller) 
    - [x] unknown/incomplete list of features
    - [ ] complicated pre-processing (transformations, data wrangling etc.)
    - [ ] OTHER: 


- [ ] H13 Unclear meaning of decision/result
   - [ ] no sound explanation of decision, e.g. with plot of decision tree, feature importances, explained thresholds/scores
   - [ ] no explanation of results giving context in domainuse case terms (e.g. for finding the root cause)
   - [ ] no confidence/severity of results given to the users
   - [ ] meaning of results to users not discussed
   - [x] OTHER: they use different threshold to reduce the size of the incident reports, that is all kind o explained so for me it's fine, and they explain what it means for users/SOCs

- [ ] H15 Important usability/interaction features (for some personas) are missing
    - [ ] no UI/User Interface/Visualization
    - [ ] no sophisticated graphical representation ('glyphs', 'highlighting') - more than standard plots (ROC,...)
    - [ ] no user interaction defined (refine, scale, select, ignore, sort)
    - [x] OTHER: doesn't seem really interactive, just a summary but overall ok


- [x] H16 Privacy not in researchers' focus
    - [ ] invasive/payload-related methods for data collection (DPI, SSL-interception, code on user devices)
    - [x] privacy, pseudonymization, anonymization, differential privacy not mentioned
    - [ ] OTHER:


- [x] H17 false positive rate non-acceptable in practise considering expected number of events (in relation to worst case)
  - [ ] FPR too high (>1%)
  - [x] FPR not given
  - [x] FPs not given
  - [x] no confidence/severity additionally given
  - [x] no implications/interpretation of high/low FN/FP/TN/TP...
  - [ ] OTHER:


- [x] H18 no comparison with state-of-the-art given    
    - [x] no comparison to other ML-based approaches
    - [x] no mention of early detection, multistage attack
    - [x] no comparision with suricata, snort,... (no comparison with signature based ids given)
    - [ ] OTHER:


- [x] H19 ignored domain knowledge
    - [ ] approach neglects contextual information  (Goodall The Work of Intrusion Detection...)
    - [x] intelligence not gathered from open source/commercial sources (5) (e.g., federated learning) - httpstalosintelligence.com
    - [x] Expert analysts cannot suggest improvements to a model by providing their feedback (7) (e.g., active learning)
    - [x] OTHER: experts can't really give feedback, are just presented results (they gave feedback for the design I guess, but not the ML models itself in the "human-in-the-loop" kind of way)

- [x] H20 no discussion of limitations/evasions
    - [ ] OTHER:
